import pandas as pd

class CSVLoader:
    def __init__(self, ruta_csv):
        self.ruta_csv = ruta_csv

    def obtener_datos_como_contexto(self, max_filas=10):
        try:
            df = pd.read_csv(self.ruta_csv)
            if df.empty:
                return "El archivo CSV está vacío."
            # Opcional: limitamos a 10 filas para no saturar tokens
            preview = df.head(max_filas).to_string(index=False)
            return f"Estos son algunos datos del CSV:\n{preview}"
        except Exception as e:
            return f"Error al leer el CSV: {str(e)}"
